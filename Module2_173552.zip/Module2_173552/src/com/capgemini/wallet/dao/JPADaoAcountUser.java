package com.capgemini.wallet.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.exception.WalletException;

public class JPADaoAcountUser {
	AccountUser user = new AccountUser();
	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();

	public void AccountUserDetail(String name, String age, String Address,
			String Email) {

		em.getTransaction().begin();

		user.setName(name);
		user.setAge(Integer.parseInt(age));
		user.setAddress(Address);
		user.setEmail(Email);
		// user.setBalance(balance);

		em.persist(user);
		em.getTransaction().commit();

		System.out.println("Added one Account user to database.");
		em.close();
		factory.close();
	}

	public boolean validateAccountNo(int Accno) throws WalletException {
		em.getTransaction().begin();
		try {
			if (em.find(AccountUser.class, Accno) != null)
				return true;

			else
				throw new WalletException("plese register for new account");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.getTransaction().commit();
		}
		return false;

	}

	public double showBalance(int Accno) throws WalletException {
		em.getTransaction().begin();

		try {

			AccountUser au = em.find(AccountUser.class, Accno);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.getTransaction().commit();

		}
		return user.getBalance();

	}
	public double depositMoney(double amount, int Accno) throws WalletException{ 
		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, Accno);
		au.setBalance(amount+user.getBalance());
		System.out.println(amount+"Rs. is credited in account number"+Accno);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.getTransaction().commit();

		}
		return user.getBalance();
	}

	public void withdrawMoney(double amount, int Accno) throws WalletException{ 
		em.getTransaction().begin();
		AccountUser au = em.find(AccountUser.class, Accno);
		
		

	}
}
