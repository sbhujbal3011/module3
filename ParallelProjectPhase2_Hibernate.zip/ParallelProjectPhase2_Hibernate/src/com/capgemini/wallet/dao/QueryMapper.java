package com.capgemini.wallet.dao;

public interface QueryMapper {

	public static String insertDetails = "insert into AccountUserY"
			 + " values(?,?,?,?,?,?)";
	
	public String sql= "select name,age,address,email,code from customer where code=?";

	String Accno = "select*from AccountUserY where code = ?";
	
	String Balance = "update accountusery set balance=balance+? where code =?";
	
	String ShowBalance ="select balance from AccountUserY where code = ?";
	
	String WithDraw = "update accountusery set balance=balance-? where code =?";
	
	String Transaction = "insert into Transaction"
			 + " values(SeqTrans.nextval,?,?,?,?)";
	
	String PrintTrans = "select * from Transaction where accno = ?";
}
