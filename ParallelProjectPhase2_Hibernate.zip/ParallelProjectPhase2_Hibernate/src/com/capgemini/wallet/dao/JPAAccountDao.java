package com.capgemini.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.bean.Transaction;
import com.capgemini.wallet.exception.WalletException;

public class JPAAccountDao {
	AccountUser au = new AccountUser();
	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("JPA-PU");

	EntityManager em = factory.createEntityManager();

	public void createUser(String name, String age, String address, String email)
			throws WalletException {

		em.getTransaction().begin();
		au.setName(name);
		au.setEmail(email);
		au.setAddress(address);
		au.setAge(Integer.parseInt(age));
		em.persist(au);
		System.out.println(au.getCode());
		em.getTransaction().commit();
		System.out.println("Added one student to database.");
		 

	}

	public boolean validateAccountNo(int Accno) throws WalletException {

		em.getTransaction().begin();
		try {
			AccountUser aus=em.find(AccountUser.class, Accno);
			if (aus != null)

				return true;// takes the record pointer to the first row and
							// then on next row
			else
				throw new WalletException("Please register for a new account ");
		} 
		finally{
			em.getTransaction().commit();
			/*
			 * em.close(); factory.close();
			 */
		}
		

	}

	public double showBalance(int Accno) throws WalletException {

		em.getTransaction().begin();

		AccountUser au = em.find(AccountUser.class, Accno);
		em.getTransaction().commit();
		return au.getBalance();

	}

	public void depositMoney(double amount, int accno) throws WalletException {
		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, accno);
			au.setBalance(amount + au.getBalance());
			System.out.println(amount + "Rs. credited to you account" + accno
					+ "successfully ");
			em.merge(au);
			em.getTransaction().commit();
			insertIntoTransaction(accno, "CR", amount, au.getBalance());
			
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

		}

	}

	public void withdrawMoney(double amount, int Accno) throws WalletException,
			ClassNotFoundException {
		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, Accno);
			if (au.getBalance() > amount) {

				au.setBalance(au.getBalance() - amount);
				System.out.println(amount + "Rs. debited to you account"
						+ Accno + "successfully ");
				em.merge(au);
				em.getTransaction().commit();
				insertIntoTransaction(Accno, "DR", amount, au.getBalance());
			} else
				throw new WalletException(
						"InSufficient Balance in the account  ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			/*
			 * em.close(); factory.close();
			 */
		}

	}

	public void fundTransfer(double amount, int accno, int Accno)
			throws ClassNotFoundException, WalletException {
		withdrawMoney(amount, Accno);
		depositMoney(amount, accno);
	}

	public void insertIntoTransaction(int Accno, String type, double amount,
			double balance) {
		em.getTransaction().begin();
		Transaction transaction = new Transaction(Accno, type, amount, balance);
		em.persist(transaction);
		em.getTransaction().commit();

	}

	public void printTransaction(int Accno) throws WalletException {
		ArrayList<Transaction> list = (ArrayList<Transaction>) em
				.createQuery(
						"Select trans from Transaction trans where Accno = :Accno order by trans,id",
						Transaction.class).setParameter("Accno", Accno)
				.getResultList();

		for (Transaction transaction : list) {
			System.out.println(transaction.printDetails());
		}
	}

}
