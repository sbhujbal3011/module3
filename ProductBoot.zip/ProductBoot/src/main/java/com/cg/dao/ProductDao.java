package com.cg.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;
@Repository
public class ProductDao implements ProductDaoI {
	
	
	@Autowired
	public ProductRepo repo;

	@Override
	public String addProduct(Product p) {
		repo.save(p);
		return "Product saved";
	}

	@Override
	public Product getProduct(int id) {
		
		return repo.findById(id).get();
	}

	@Override
	public String updateProduct(Product p) {
		repo.save(p);
		return "Product updated";
	}

	@Override
	public String deleteProduct(int id) {
		repo.deleteById(id);
		return "Product deleted";
	}

}



