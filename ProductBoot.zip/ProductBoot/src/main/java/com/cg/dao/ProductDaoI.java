package com.cg.dao;

import com.cg.entity.Product;

public interface ProductDaoI {

	String addProduct(Product p);

	Product getProduct(int id);

	String updateProduct(Product p);

	String deleteProduct(int id);

}
