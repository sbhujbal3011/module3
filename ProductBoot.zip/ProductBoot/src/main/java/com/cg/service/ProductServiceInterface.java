package com.cg.service;

import com.cg.entity.Product;

public interface ProductServiceInterface {
	public String addProduct(Product p);

	public Product getProduct(int id);

	public String updateProduct(Product p);

	public String deleteProduct(int id);

}
