package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductDao;
import com.cg.entity.Product;
import com.cg.repo.ProductRepo;
@Service
public class ProductService implements ProductServiceInterface {
	@Autowired
	public ProductDao dao;

	@Override
	public String addProduct(Product p) {
		
		return dao.addProduct(p);
	}

	@Override
	public Product getProduct(int id) {
		
		return dao.getProduct(id);
	}

	@Override
	public String updateProduct(Product p) {
		
		return dao.addProduct(p);
	}

	@Override
	public String deleteProduct(int id) {
		
		return dao.deleteProduct(id);
	}

}
