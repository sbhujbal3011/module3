package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;

@RestController
public class HelloController {

	@Autowired
	ProductService service;

	@GetMapping("/hola/{name}")
	public String sayHello(@PathVariable("name") String name) {
		return "Hello " + name + ",WElcome to springBoot";
	}

	@GetMapping("/bye")
	public String sayGoodbye(@RequestParam("name") String name) {
		return "Bye" + name + ",Visit again";
	}

	@PostMapping("/add")
	public String saveProduct(@RequestParam("name") String name, @RequestParam("price") double price) {

		Product p1 = new Product();
		p1.setName(name);
		p1.setPrice(price);

		service.addProduct(p1);
		return "Product save";
	}

	@GetMapping(path = "/product", produces = "application/json")
	public Product getProduct(@RequestParam("id") int id) {
		Product p1 = service.getProduct(id);
		return p1;
	}
	/*
	 * @GetMapping(path = "/productall", produces = "application/json") public
	 * List<Product> getAllProduct() {
	 * 
	 * return .getAll(); }
	 */

	@GetMapping(path = "/productupdate", produces = "application/json")
	public String updateProduct(@RequestParam("name") String name, @RequestParam("price") double price,
			@RequestParam("id") int id) {
		Product p1 = new Product();
		p1.setId(id);
		p1.setName(name);
		p1.setPrice(price);

		return service.updateProduct(p1);

	}

	@DeleteMapping(path = "/productdelete")
	public String deleteProduct(@RequestParam("id") int id) {
		String p1 = service.deleteProduct(id);
		return "product deleted";
		
	}

}
