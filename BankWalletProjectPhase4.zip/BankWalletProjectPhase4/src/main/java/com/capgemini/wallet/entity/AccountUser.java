package com.capgemini.wallet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity //compulsory annotation 
@Table(name = "AccountUserY") 

public class AccountUser {
	
	
	
	@Column(length=20)
	private String name;
	private int age;
	@Column(length=30)
	private String Address;
	@Column(length=30)
	private String Email;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) //compulsory annotation denotes primary key
	private int code;
	private double balance;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "AccountUser [name=" + name + ", age=" + age + ", Address="
				+ Address + ", Email=" + Email + ", code=" + code + "]";
	}

}
