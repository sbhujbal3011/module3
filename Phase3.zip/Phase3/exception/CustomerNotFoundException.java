package com.capgemni.citi.exception;

public class CustomerNotFoundException extends Exception {

	public CustomerNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
