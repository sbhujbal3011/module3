package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.AccountUser;
import com.cg.bean.Transaction;
import com.cg.exception.WalletException;

@Repository("spring")
public class SpringWalletDaoImpl implements SpringWalletDao  {
	AccountUser au = new AccountUser();

	@Autowired
	private ApplicationContext context;
	
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	@Transactional(propagation = Propagation.REQUIRES_NEW)// CMT: if existing not found it start new transaction
	public void createUser(AccountUser auU) throws WalletException {

		em.persist(auU);

		System.out.println("Added one student to database.");

	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW) // CMT:if not found its ok
	public boolean validateAccountNo(int Accno) throws WalletException {

		try {
			AccountUser aus = em.find(AccountUser.class, Accno);
			if (aus != null)

				return true;// takes the record pointer to the first row and
							// then on next row
			else
				throw new WalletException("Please register for a new account ");
		} finally {

		}

	}

	
	@Transactional
	public double showBalance(int Accno) throws WalletException {

		AccountUser au = em.find(AccountUser.class, Accno);

		return au.getBalance();

	}


	@Transactional
	public void depositMoney(double amount, int accno) throws WalletException {

		try {
			AccountUser au = em.find(AccountUser.class, accno);
			au.setBalance(amount + au.getBalance());
			System.out.println(amount + "Rs. credited to you account" + accno + "successfully ");
			em.merge(au);

			insertIntoTransaction(accno, "CR", amount, au.getBalance());

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

		}

	}
	
	
	
	@Transactional
	public void withdrawMoney(double amount, int Accno) throws WalletException, ClassNotFoundException {

		try {
			AccountUser au = em.find(AccountUser.class, Accno);
			if (au.getBalance() > amount) {

				au.setBalance(au.getBalance() - amount);
				System.out.println(amount + "Rs. debited to you account" + Accno + "successfully ");
				em.merge(au);

				insertIntoTransaction(Accno, "DR", amount, au.getBalance());
			} else
				throw new WalletException("InSufficient Balance in the account  ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			/*
			 * em.close(); factory.close();
			 */
		}

	}

	
	@Transactional
	public void fundTransfer(double amount, int accno, int Accno) throws ClassNotFoundException, WalletException {
		withdrawMoney(amount, Accno);
		depositMoney(amount, accno);
	}

	
	@Transactional
	public void insertIntoTransaction(int Accno, String type, double amount, double balance) {

		Transaction transaction = new Transaction(Accno, type, amount, balance);
		em.persist(transaction);

	}

	
	@Transactional
	public List<Transaction> getAll() {
		return em.createQuery("from Transaction").getResultList();
	}

	
	@Transactional
	public void printTransaction(int Accno) throws WalletException {
		ArrayList<Transaction> list = (ArrayList<Transaction>) em
				.createQuery("Select trans from Transaction trans where Accno = :Accno order by trans,id",
						Transaction.class)
				.setParameter("Accno", Accno).getResultList();

		for (Transaction transaction : list) {
			System.out.println(transaction.printDetails());
		}
	}

	
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub
		
	}

}
