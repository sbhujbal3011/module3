import { Component, OnInit } from '@angular/core';
import { TodolistService } from '../service/todolist.service';
import { TodolistModel } from '../Models/Todolist';

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.component.html',
  styleUrls: ['./to-do.component.css']
})
export class ToDoComponent implements OnInit {

  TodoListArr:TodolistModel[];
  ToDoToEdit:TodolistModel;
  isEditing:boolean;

  constructor(private TodoService:TodolistService) { 
    this.TodoListArr = [];
    this.ToDoToEdit = new TodolistModel;
  }

  ngOnInit() {
    this. TodoListArr= this.TodoService.getTodo();
  }
  delete(index: number) {
    this.TodoService.delete(index);
   }
 
   edit(id:number)
   {
     this.isEditing = true;
     this.ToDoToEdit = this.TodoService.edit(id);
   }
}