export class TodolistModel {
    public EmailAddress: String;
    public ID: number;
    public Password: String;
  

    

}