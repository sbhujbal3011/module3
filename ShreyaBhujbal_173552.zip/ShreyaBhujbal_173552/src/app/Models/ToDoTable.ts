export class ToDoTable{
    public ID: number
    public Name:String;
    public Status:String;
}