import { Component, OnInit } from '@angular/core';
import { TodolistModel } from '../Models/Todolist';
import { TodolistService } from '../service/todolist.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {
  Todolist: TodolistModel;//BOOKMARK

 //initilize it
  constructor(private TodoService:TodolistService) {
    this.Todolist = new TodolistModel();
  }

  add() {
    this.TodoService.add(this.Todolist );
     this.Todolist  = new TodolistModel();
   }

}
