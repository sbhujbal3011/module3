import { Injectable } from '@angular/core';
import { TodolistModel } from '../Models/Todolist';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TodolistService {
  TodoListArr: TodolistModel[];

  constructor(private routes:Router) {
    this.TodoListArr = [];
  }
  add(Todolist:TodolistModel){
    this.routes.navigate(['/to-do']);
  }
  getTodo() {
    return this.TodoListArr;
  }

  delete(index: number) {
    this.TodoListArr.splice(index, 1);
  }

  edit(id: number) {
    return this.TodoListArr.find(x => x.ID== id);
  }


}
