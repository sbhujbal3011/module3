package com.ParallelProjectTest.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Repository;

import com.ParallelProjectTest.Exception.BalanceException;
import com.ParallelProjectTest.Exception.WalletException;
import com.ParallelProjectTest.bean.CustomerBean;

@Repository
public class Dao implements IDao {

	static Map<Integer, CustomerBean> detiMap = new HashMap<Integer, CustomerBean>();

	static Map<Integer, Double> balMap = new HashMap<Integer, Double>();

	Transaction[] txns = new Transaction[10];
	int idx;

	
	@Override
	public void creatAccount(String name, String mobile, String email) throws WalletException, SQLException {

		CustomerBean cust = new CustomerBean(name, Long.parseLong(mobile), email);

		int acntNo = (int) (Math.random() * 1000);

		cust.setAcntNo(acntNo);

		detiMap.put(acntNo, cust);

		balMap.put(acntNo, 0.0); // As initial balance is zero

		System.out.println(detiMap.get(acntNo));
		txns[idx++] = new Transaction(acntNo, "Initial", 0, 0);

	}

	@Override
	public boolean logIn(String acntNo) throws NumberFormatException, SQLException {

		if (detiMap.containsKey(Integer.parseInt(acntNo))) {

			return true;
		}

		return false;

	}

	@Override
	public Double showBalance(String acntNo) throws NumberFormatException {

		return balMap.get(Integer.parseInt(acntNo));
	}

	@Override
	public void deposit(String acntNo, Double amount) throws NumberFormatException, SQLException {

		balMap.put(Integer.parseInt(acntNo), (balMap.get(Integer.parseInt(acntNo)) + amount));

		txns[idx++] = new Transaction(Integer.parseInt(acntNo), "CR", balMap.get(Integer.parseInt(acntNo)), amount);

	}

	@Override
	public void withdraw(String acntNo, String amount) throws BalanceException, NumberFormatException, SQLException {
		if (Double.parseDouble(amount) <= balMap.get(Integer.parseInt(acntNo))) {

			balMap.put(Integer.parseInt(acntNo), (balMap.get(Integer.parseInt(acntNo)) - Double.parseDouble(amount)));

			System.out.println(amount + " withdraw from your account");

			txns[idx++] = new Transaction(Integer.parseInt(acntNo), "WR", balMap.get(Integer.parseInt(acntNo)),
					Double.parseDouble(amount));

		} else {
			System.out.println("You have insufficient balance. Please add money first");
		}
	}

	@Override
	public void fundTransfer(String sendAccNo, String recAcntNo, String amount)
			throws BalanceException, NumberFormatException, SQLException {
		if (balMap.containsKey(Integer.parseInt(recAcntNo))) {

			if (Double.parseDouble(amount) <= balMap.get(Integer.parseInt(sendAccNo))) {

				balMap.put(Integer.parseInt(sendAccNo),
						balMap.get(Integer.parseInt(sendAccNo)) - Double.parseDouble(amount));

				balMap.put(Integer.parseInt(recAcntNo),
						balMap.get(Integer.parseInt(recAcntNo)) + Double.parseDouble(amount));

				System.out.println(amount + " Transfer done ");

				txns[idx++] = new Transaction(Integer.parseInt(sendAccNo), "FT",
						balMap.get(Integer.parseInt(sendAccNo)), Double.parseDouble(amount));

				txns[idx++] = new Transaction(Integer.parseInt(recAcntNo), "FT",
						balMap.get(Integer.parseInt(recAcntNo)), Double.parseDouble(amount));

			}

		} else
			System.out.println("Receiver not found \nPlease enter valid details");
	}

	@Override
	public String printTransaction(String acntNo) {
		for (int i = 0; i < idx; i++) {
			txns[i].print(Integer.parseInt(acntNo));
		}
		return null;
	}

	

}
