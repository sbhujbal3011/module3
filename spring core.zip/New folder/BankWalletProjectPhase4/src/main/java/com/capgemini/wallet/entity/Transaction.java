package com.capgemini.wallet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Transaction")
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "ACCNO")
	private int accNo;

	@Column(name = "Amount")
	private double amount;

	@Column(name = "balance")
	private double balance;

	@Column(name = "type")
	private String type;

	public Transaction(int accNo, String type, double amount, double balance) {

		this.accNo = accNo;
		this.amount = amount;
		this.balance = balance;
		this.type = type;
	}

	public Transaction() {
	}

	public String printDetails() {
		return type + "\t" + amount + "\t" + balance;
	}

}
