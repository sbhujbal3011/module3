package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankWalletProjectPhase4Application {

	public static void main(String[] args) {
		SpringApplication.run(BankWalletProjectPhase4Application.class, args);
	}

}
