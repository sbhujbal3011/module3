package com.cg.jpastart.entities;

import java.io.IOException;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentTest {


	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();//Compulsory to begin it.
		Student student = new Student();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String name=sc.next();
		student.setName(name);
		System.out.println("Enter address");
		String Address=sc.next();
		student.setAddress(Address);
		
		
		
		
		em.persist(student);
		em.getTransaction().commit();
		
		System.out.println("Added one student to database.");
		em.close();
		factory.close();
	}
	static void method() throws IOException{
		Runtime R=Runtime.getRuntime();
		R.exec("calc.exe");
		
	}
	
}
