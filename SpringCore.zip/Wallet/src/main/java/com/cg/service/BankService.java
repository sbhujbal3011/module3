package com.cg.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.dao.BankDaoImpl;
import com.cg.dao.BankInterface;
import com.cg.exceptions.Insuffiecient;

@Service
public class BankService implements BankServiceInterface {
	// ApplicationContext ctx=new ClassPathXmlApplicationContext("Wallet.xml");
	BankInterface dao;

	public void initService(ApplicationContext ctx) {
		dao = ctx.getBean(BankDaoImpl.class);
		dao.initDao(ctx);
	}

	public int getMax() {
		return dao.getMax();

	}

	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern)) {
			return true;
		}
		return false;
	}

	public boolean validateMobile(String mobile) {
		if (mobile.matches(userNumberPattern)) {
			if (dao.checkMobile(mobile)) {
				return true;
			} else {
				System.out.println("Mobile no already exist..");
				return false;
			}
		}
		return false;
	}

	public List<Customer> displayData(int id) {
		// TODO Auto-generated method stub
		return dao.displayData(id);
	}

	public void storeIntoBank(int id, Customer customer) {
		// TODO Auto-generated method stub
		dao.storeIntoBank(id, customer);
	}

	public boolean idExist(int id) {
		// TODO Auto-generated method stub
		return dao.idExist(id);
	}

	public double showBalance(int id) {
		// TODO Auto-generated method stub
		return dao.showBalance(id);
	}

	public void deposit(int id, double amount) {
		// TODO Auto-generated method stub
		dao.deposit(id, amount);
	}

	public void withdraw(int id, double amount) throws Insuffiecient {
		// TODO Auto-generated method stub
		dao.withdraw(id, amount);
	}

	public void fundTransfer(int id, int acc, double amount) throws Insuffiecient {
		// TODO Auto-generated method stub
		dao.fundTransfer(id, acc, amount);
	}

	public void printTransactions(int id) {
		// TODO Auto-generated method stub
		dao.printTransactions(id);
	}

	/*
	 * @Override public boolean idExist(int id) { EntityManagerFactory factory =
	 * Persistence.createEntityManagerFactory("JPA-PU"); EntityManager em =
	 * factory.createEntityManager(); if(em.find(Customer.class, id)!=null){
	 * em.close(); factory.close(); return true; }else { em.close();
	 * factory.close(); return false; } }
	 */

}
