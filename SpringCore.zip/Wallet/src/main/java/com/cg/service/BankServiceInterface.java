package com.cg.service;

import java.util.List;

import org.springframework.context.ApplicationContext;

import com.cg.bean.Customer;
import com.cg.exceptions.Insuffiecient;

public interface BankServiceInterface {
	String userNamePattern = "[A-Z][a-z]{1,9}";
	String userNumberPattern = "[0-9]{10}";

	boolean validateUserName(String userName);

	boolean validateMobile(String mobile);

	public List<Customer> displayData(int id);

	void storeIntoBank(int id, Customer customer);

	public boolean idExist(int id);

	double showBalance(int id);

	void deposit(int id, double amount);

	void withdraw(int id, double amount) throws Insuffiecient;

	void fundTransfer(int id, int acc, double amount) throws Insuffiecient;

	void printTransactions(int id);

	public int getMax();

	public void initService(ApplicationContext ctx);

}
