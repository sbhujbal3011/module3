package com.cg.dao;

import java.util.List;

import org.springframework.context.ApplicationContext;

import com.cg.bean.Customer;
import com.cg.exceptions.Insuffiecient;

public interface BankInterface {

	public List<Customer> displayData(int id);

	void storeIntoBank(int id, Customer customer);

	public boolean idExist(int id);

	double showBalance(int id);

	void deposit(int id, double amount);

	void withdraw(int id, double amount) throws Insuffiecient;

	void fundTransfer(int id, int acc, double amount) throws Insuffiecient;

	void printTransactions(int id);

	public int getMax();

	public boolean checkMobile(String mobile);

	public void initDao(ApplicationContext ctx);

}
