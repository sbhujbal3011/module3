package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Repository;

import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exceptions.Insuffiecient;

@Repository
public class BankDaoImpl implements BankInterface {

	double balance;
	Map<Integer, Customer> cMap = new HashMap<Integer, Customer>();
	List<Transaction> txn = new ArrayList<Transaction>();

	public List<Customer> displayData(int id) {
		List<Customer> list1 = new ArrayList<Customer>();
		list1.add(cMap.get(id));
		return list1;
	}

	public void initDao(ApplicationContext ctx) {
		// TODO Auto-generated method stub
		Customer customer = ctx.getBean(Customer.class);
		Transaction transaction = ctx.getBean(Transaction.class);
	}

	public void storeIntoBank(int id, Customer customer) {
		// TODO Auto-generated method stub
		cMap.put(id, customer);

	}

	public boolean idExist(int id) {
		// TODO Auto-generated method stub
		if (cMap.containsKey(id)) {
			return true;
		}
		return false;
	}

	public double showBalance(int id) {
		// TODO Auto-generated method stub
		return cMap.get(id).getBalance();
	}

	public void deposit(int id, double amount) {
		// TODO Auto-generated method stub
		balance = cMap.get(id).getBalance();
		balance += amount;
		cMap.get(id).setBalance(balance);
		txn.add(new Transaction("CR", amount, balance, id));
	}

	public void withdraw(int id, double amount) throws Insuffiecient {
		// TODO Auto-generated method stub
		balance = cMap.get(id).getBalance();
		if (balance >= amount) {
			balance -= amount;
			cMap.get(id).setBalance(balance);
			txn.add(new Transaction("DR", amount, balance, id));
		} else {
			throw new Insuffiecient("Insufficient Fund for Transaction!.");
		}
	}

	public void fundTransfer(int id, int acc, double amount) throws Insuffiecient {
		// TODO Auto-generated method stub
		if (cMap.get(id).getBalance() >= amount) {
			deposit(acc, amount);
			withdraw(id, amount);
		} else {
			throw new Insuffiecient("Insufficient Fund for Transaction!.");
		}
	}

	public void printTransactions(int id) {
		// TODO Auto-generated method stub
		for (Transaction transaction : txn) {
			if (transaction.getId() == id)
				System.out.println(transaction);
		}
	}

	public int getMax() {
		// returns currnt size of map
		return cMap.size();
	}

	public boolean checkMobile(String mobile) {
		// TODO Auto-generated method stub
		for (Map.Entry<Integer, Customer> i : cMap.entrySet()) {
			if (mobile.equals(i.getValue().getMobile())) {
				return false;
			}
		}
		return true;
	}

}
