package com.cg.exceptions;

public class InvalidDetails extends Exception {

	public InvalidDetails(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
