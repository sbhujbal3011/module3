package com.cg.exceptions;

public class NotExist extends Exception {

	public NotExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
