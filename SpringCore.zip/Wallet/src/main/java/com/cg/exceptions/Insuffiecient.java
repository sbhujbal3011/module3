package com.cg.exceptions;

public class Insuffiecient extends Exception {

	public Insuffiecient(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
