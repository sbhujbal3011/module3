package com.cg.bean;

import org.springframework.stereotype.Component;

@Component
public class Customer {
	
	private int accountNo;
	private String name;
	private String mobile;
	private double balance;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int accountNo, String name, String mobile, double balance) {
		//super();
		this.accountNo = accountNo;
		this.name = name;
		this.mobile = mobile;
		this.balance = balance;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", name=" + name
				+ ", mobile=" + mobile + ", balance=" + balance + "]";
	}

}
