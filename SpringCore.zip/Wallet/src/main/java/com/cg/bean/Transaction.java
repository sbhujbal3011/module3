package com.cg.bean;

import org.springframework.stereotype.Component;

@Component
public class Transaction {
	
	private int sn=1;
	private int id;
	private double amount;
	private double balance;
	private String type;

	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	
	public Transaction(String type,double amount, double balance,int id) {
		//super();
		this.sn=sn++;
		this.id=id;
		this.amount = amount;
		this.balance = balance;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public int getSn() {
		return sn;
	}

	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", balance=" + balance + ", type=" + type + "]";
	}

}
