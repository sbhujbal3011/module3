package com.cg.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Customer;
import com.cg.exceptions.Insuffiecient;
import com.cg.exceptions.InvalidDetails;
import com.cg.exceptions.NotExist;
import com.cg.service.BankService;
import com.cg.service.BankServiceInterface;

public class Account {

	public static void main(String[] args) throws NotExist, Insuffiecient, InvalidDetails {

		Scanner sc = new Scanner(System.in);
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Wallet.xml");
		BankServiceInterface service=ctx.getBean(BankService.class);
		service.initService(ctx);
//		BankServiceInterface service = new BankService();
		Customer cust;
		int id;
		String name,mobile;
		double balance = 0;

		System.out.println("Welcome to Apna Bank!!!");
		do {
			System.out.print("1. Create new Account\n2. Login\n3. Exit\nEnter your choice : ");
			int op = sc.nextInt();

			if (op == 1) {
				//cust=ctx.getBean(Customer.class);
				while (true) {
					System.out.print("Enter Your Name with first letter capital : ");
					name = sc.next();
					if (service.validateUserName(name)) {
						//cust.setName(name);
						break;
					}
				}

				while (true) {
					System.out.print("Enter Your Mobile Number : ");
					mobile = sc.next();
					if (service.validateMobile(mobile)) {
						//cust.setMobile(mobile);
						break;
					} else {
						System.out.println("Please Enter 10 digit number without country code..");
					}
				}

				
					int accno=service.getMax();
						accno+=1;
						//cust.setAccountNo(accno);
						//cust.setBalance(0);
					System.out.println("Customer Information saved successfully..");
					cust = new Customer(accno,name, mobile,balance);
					service.storeIntoBank(accno, cust);
					System.out.println("Your Account Details are : ");
					System.out.println(service.displayData(accno));
					accno++;
//				}
			}
			else if (op == 2) {

				System.out.println("Enter your Account no: ");
				id = sc.nextInt();
				if (service.idExist(id)) {
					while (true) {
						System.out.print(
								"1. Show Balance\n2. Deposit\n3. Withdraw\n4. Fund Transfer\n5. Print Transactions\n6. Exit\nEnter your choice : ");
						op = sc.nextInt();
						if (op == 6)
							break;
						else {
							switch (op) {
							case 1:
								System.out.println(service.showBalance(id));
								break;

							case 2:
								System.out.println("Enter the amount to be deposited: ");
								service.deposit(id, sc.nextDouble());
								// service.storeIntoBank(id,cust);
								break;

							case 3:
								System.out.println("Enter the amount to be withdraw: ");
								service.withdraw(id, sc.nextDouble());
								// service.storeIntoBank(id,cust);
								break;

							case 4:
								System.out.println("Enter Recievers Account no: ");
								int acc = sc.nextInt();
								if(id==acc){
									throw new InvalidDetails("Senders and Receivers Account Number Cannot be Same!");
								}
								else if(service.idExist(acc)){
								System.out.println("Enter the amount to be Transferred: ");
								service.fundTransfer(id, acc, sc.nextDouble());
								
								}else {
									throw new NotExist("Receivers account does not exist in Database!..");
	
								}
								break;
							case 5:service.printTransactions(id);
								break;

							default:
								throw new InvalidDetails("Sorry! you have choosen wrong Option");
							}
						}
					}
				}

				else if (!service.idExist(id)) {
					throw new NotExist("Sorry!Account for given Id does not Exist.");
				}
			}
			else if (op == 3) {
				System.out.println("Thank you....");
				System.exit(0);
			}
			else {
				throw new InvalidDetails("Sorry! you have choosen wrong Option");
			}

		} while (true);

	}

}
