/**
 * 
 */
package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author sbhujbal
 *
 */

@Entity
@Table(name = "Album_Info")
public class Album {

	@Id
	@Column(name = "album_Id")
	@GeneratedValue
	private int albumId;

	@Column(name = "album_title", length = 20)
	private String albumTitle;

//	@Column(name = "album_artist", length = 20)
	private String albumArtist;

	@Column(name = "album_price", length = 5)
	private double albumPrice;

	/**
	 * @return the albumId
	 */
	public int getAlbumId() {
		return albumId;
	}

	/**
	 * @param albumId
	 *            the albumId to set
	 */
	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	/**
	 * @return the albumTitle
	 */
	public String getAlbumTitle() {
		return albumTitle;
	}

	/**
	 * @param albumTitle
	 *            the albumTitle to set
	 */
	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	/**
	 * @return the albumArtist
	 */
	public String getAlbumArtist() {
		return albumArtist;
	}

	/**
	 * @param albumArtist
	 *            the albumArtist to set
	 */
	public void setAlbumArtist(String albumArtist) {
		this.albumArtist = albumArtist;
	}

	/**
	 * @return the albumPrice
	 */
	public double getAlbumPrice() {
		return albumPrice;
	}

	/**
	 * @param albumPrice
	 *            the albumPrice to set
	 */
	public void setAlbumPrice(double albumPrice) {
		this.albumPrice = albumPrice;
	}

}
