/**
 * 
 */
package com.cg.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Album;

import com.cg.service.AlbumService;

/**
 * @author sbhujbal
 *
 */
@RestController
public class AlbumController {

	@Autowired
	AlbumService service;

	@PostMapping(path = "/addAlbum", consumes = "application/json")
	public String saveMusicAlbum(@RequestBody Album a) {
		service.saveAlbum(a);
		return "Album is Saved";
	}

	@GetMapping(path = "/getAlbum/{albumId}", produces = "application/json")
	public ResponseEntity<Album> getMusicAlbum(@PathVariable("albumId") int albumId) {
		try {
			Album a = service.getAlbum(albumId);
			return new ResponseEntity<Album>(a, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path = "/getAlbumbyname/{artist}", produces = "application/json")
	public Album getMusicAlbumbyName(@PathVariable("artist") String artist) {
		Album a = service.getAlbumByName(artist);
		return a;
	}

	@GetMapping(path = "/getAllAlbum", produces = "application/json")
	public Iterable<Album> getAll() {
		return service.getAllAlbum();
	}

	@PutMapping(path = "/update/{id}", consumes = "application/json")
	public Album updateAlbum(@PathVariable("id") int albumId, @RequestBody Album a) {
		return service.updateAlbum(a, albumId);

	}

	@DeleteMapping(path = "/deleteAlbum/{albumId}")
	public String deletAlbum(@PathVariable("albumId" + "") int albumId) {
		service.deleteAlbum(albumId);
		return "Album deleted";
	}
}
