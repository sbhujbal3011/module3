/**
 * 
 */
package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Album;

/**
 * @author sbhujbal
 *
 */
public interface AlbumRepo extends CrudRepository<Album, Integer> {
	
	Album findByalbumArtist(String artist);

	
	

}
