/**
 * 
 */
package com.cg.service;

import com.cg.entity.Album;

/**
 * @author sbhujbal
 *
 */
public interface AlbumService {

	void saveAlbum(Album a);

	Album getAlbum(int albumId);

	Iterable<Album> getAllAlbum();

	public String deleteAlbum(int albumId);

	public Album updateAlbum(Album a, int albumId);

	Album getAlbumByName(String albumTitle);

}
